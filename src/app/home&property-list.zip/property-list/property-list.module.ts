import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PropertyListRoutingModule } from './property-list-routing.module';
import { PropertyListComponent } from './property-list.component';


@NgModule({
  declarations: [PropertyListComponent],
  imports: [
    CommonModule,
    PropertyListRoutingModule
  ]
})
export class PropertyListModule { }
